module.exports = [{
      plugin: require('../node_modules/gatsby-plugin-manifest/gatsby-browser.js'),
      options: {"plugins":[],"name":"COVID-19 Tracker","short_name":"COVID-19 Tracker","description":"Global Coronavirus Outbreak Tracker","icon":"src/images/favicon.png","start_url":"/","background_color":"#EFF1F6","theme_color":"#02d587","display":"standalone"},
    },{
      plugin: require('../node_modules/gatsby-plugin-offline/gatsby-browser.js'),
      options: {"plugins":[],"workboxConfig":{"globPatterns":["**/*"]}},
    }]
