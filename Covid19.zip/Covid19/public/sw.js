/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("workbox-v4.3.1/workbox-sw.js");
workbox.setConfig({modulePathPrefix: "workbox-v4.3.1"});

workbox.core.setCacheNameDetails({prefix: "gatsby-plugin-offline"});

workbox.core.skipWaiting();

workbox.core.clientsClaim();

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "about/index.html",
    "revision": "bddf2785f46dd664acb1151ca879cabe"
  },
  {
    "url": "allCountries/index.html",
    "revision": "6f78bca93a3d2615dab4c5bd06658043"
  },
  {
    "url": "app-278672efeec7eca81a90.js"
  },
  {
    "url": "app-278672efeec7eca81a90.js.map",
    "revision": "6d2381992ead4b875d38ae3bdf78ca0d"
  },
  {
    "url": "chunk-map.json",
    "revision": "bf8b74e611d7b065cfaf584779c1c913"
  },
  {
    "url": "commons-010e94030db2ce969073.js"
  },
  {
    "url": "commons-010e94030db2ce969073.js.map",
    "revision": "3f13629c04139e6fa579e7b86d76f45f"
  },
  {
    "url": "commons-8fd64c4d45ac9a30e0b1.js"
  },
  {
    "url": "commons-8fd64c4d45ac9a30e0b1.js.map",
    "revision": "2bb4a7669640efb378fed09b906a81a1"
  },
  {
    "url": "component---cache-caches-gatsby-plugin-offline-app-shell-js-0159bb149368cfb6a796.js"
  },
  {
    "url": "component---cache-caches-gatsby-plugin-offline-app-shell-js-0159bb149368cfb6a796.js.map",
    "revision": "659d918a92956767b6a12ba27f64a340"
  },
  {
    "url": "component---src-pages-about-js-21f9c86810f7fc997523.js"
  },
  {
    "url": "component---src-pages-about-js-21f9c86810f7fc997523.js.map",
    "revision": "0e5265a722f977a8dd051973582a9ee9"
  },
  {
    "url": "component---src-pages-about-js-6ca3e1989c645fcd64ee.js"
  },
  {
    "url": "component---src-pages-about-js-6ca3e1989c645fcd64ee.js.map",
    "revision": "5c0f17a64bc22effe66dee6dcd520721"
  },
  {
    "url": "component---src-pages-about-js-7c2128531e5f2390a7d1.js"
  },
  {
    "url": "component---src-pages-about-js-7c2128531e5f2390a7d1.js.map",
    "revision": "ea347b95c45cb94dd2585e2f8b95adc5"
  },
  {
    "url": "component---src-pages-all-countries-js-5ac880d08bb8f94ab33a.js"
  },
  {
    "url": "component---src-pages-all-countries-js-5ac880d08bb8f94ab33a.js.map",
    "revision": "a159083e3513e2e6e70a22d4c2639b59"
  },
  {
    "url": "component---src-pages-all-countries-js-5dbbea371dae9e52b840.js"
  },
  {
    "url": "component---src-pages-all-countries-js-5dbbea371dae9e52b840.js.map",
    "revision": "87329d9cf14788d381270996a2a00cc8"
  },
  {
    "url": "component---src-pages-all-countries-js-bea2eb2264531d0eb3e9.js"
  },
  {
    "url": "component---src-pages-all-countries-js-bea2eb2264531d0eb3e9.js.map",
    "revision": "40d2175f868b470a1e59bbf7af1369eb"
  },
  {
    "url": "component---src-pages-all-countries-js-c22160a84e6f778b85a2.js"
  },
  {
    "url": "component---src-pages-all-countries-js-c22160a84e6f778b85a2.js.map",
    "revision": "c03a9e415c1367c1937dd4fa70712c3a"
  },
  {
    "url": "component---src-pages-index-js-2e84da048273d2331147.js"
  },
  {
    "url": "component---src-pages-index-js-2e84da048273d2331147.js.map",
    "revision": "29d1392fd92098c9eaf021d6eafa8146"
  },
  {
    "url": "component---src-pages-index-js-6866020730adacadb5c7.js"
  },
  {
    "url": "component---src-pages-index-js-6866020730adacadb5c7.js.map",
    "revision": "d9cb498d301db2c86838a7d235d7a06f"
  },
  {
    "url": "component---src-pages-index-js-a3c25ac24aa2c3faae7e.js"
  },
  {
    "url": "component---src-pages-index-js-a3c25ac24aa2c3faae7e.js.map",
    "revision": "49fce95f780c695ef534de9b50481d33"
  },
  {
    "url": "component---src-pages-index-js-a858629cf8e76e8be850.js"
  },
  {
    "url": "component---src-pages-index-js-a858629cf8e76e8be850.js.map",
    "revision": "cc9afb382acb988895159ea2d32b4542"
  },
  {
    "url": "component---src-pages-index-js-ab5eef5dcb511a7f6057.js"
  },
  {
    "url": "component---src-pages-index-js-ab5eef5dcb511a7f6057.js.map",
    "revision": "b08e513dc829b9bb48bc51ea99fa9487"
  },
  {
    "url": "component---src-pages-index-js-ff766171ebd617ae62a3.js"
  },
  {
    "url": "component---src-pages-index-js-ff766171ebd617ae62a3.js.map",
    "revision": "77db255390ea554d670581cd97580a36"
  },
  {
    "url": "icons/icon-144x144.png",
    "revision": "e3ea896f66d1708704f676d32b38ff34"
  },
  {
    "url": "icons/icon-192x192.png",
    "revision": "721f8b607cac54e36b7b428f81cf1068"
  },
  {
    "url": "icons/icon-256x256.png",
    "revision": "b5f9dc417b486eef5dcb5037cd963b5d"
  },
  {
    "url": "icons/icon-384x384.png",
    "revision": "22dd674c16c03786a3921a8d6e57486d"
  },
  {
    "url": "icons/icon-48x48.png",
    "revision": "41f8249c3154b4ed3aa103b5a24b51b4"
  },
  {
    "url": "icons/icon-512x512.png",
    "revision": "13e6b018f809b99fae9420602e381a3c"
  },
  {
    "url": "icons/icon-72x72.png",
    "revision": "6964c3e92b5dd280c4f7bd5bd05ab527"
  },
  {
    "url": "icons/icon-96x96.png",
    "revision": "78937050d0b5760fcc129b12873d0a3e"
  },
  {
    "url": "idb-keyval-iife.min.js"
  },
  {
    "url": "index.html",
    "revision": "dc055aaee3c1d9878ca335c328129b43"
  },
  {
    "url": "manifest.webmanifest",
    "revision": "98405ffb9c9a2778925be22280703bfa"
  },
  {
    "url": "offline-plugin-app-shell-fallback/index.html",
    "revision": "37ba3fd863d3978488e2f40270fffd4d"
  },
  {
    "url": "page-data/about/page-data.json",
    "revision": "3ddd5d51b095997b4d473ef99898912f"
  },
  {
    "url": "page-data/allCountries/page-data.json",
    "revision": "97667272f7e3d7cf5d16cd9ceff251a0"
  },
  {
    "url": "page-data/app-data.json",
    "revision": "f188774eacfd58dd52583d1730e6954a"
  },
  {
    "url": "page-data/index/page-data.json",
    "revision": "7ccb1677a3924eb7498e27ccb409e361"
  },
  {
    "url": "page-data/offline-plugin-app-shell-fallback/page-data.json",
    "revision": "43232b01cc861c0701a3ece4bd67720b"
  },
  {
    "url": "static/d/768287408.json"
  },
  {
    "url": "static/logo-ab683aa24cb10d2f91dbe822e3b2feeb.svg"
  },
  {
    "url": "styles-67163425f3ac76124843.js"
  },
  {
    "url": "styles-67163425f3ac76124843.js.map",
    "revision": "17238da334c20ee672783ad04d517bac"
  },
  {
    "url": "styles.31a89e3c15ed19e7ecea.css"
  },
  {
    "url": "webpack-runtime-121250b6b7df4df3b380.js"
  },
  {
    "url": "webpack-runtime-121250b6b7df4df3b380.js.map",
    "revision": "1f3b70308ac24bf7c948ad3514c97b3a"
  },
  {
    "url": "webpack-runtime-2c9d6e1dbabd8d8d1704.js"
  },
  {
    "url": "webpack-runtime-2c9d6e1dbabd8d8d1704.js.map",
    "revision": "57c2124a539340c262a3bc1bd543f5b5"
  },
  {
    "url": "webpack-runtime-40843dff32eb2c458ae6.js"
  },
  {
    "url": "webpack-runtime-40843dff32eb2c458ae6.js.map",
    "revision": "f3f98fe358dc140160906882d18765a0"
  },
  {
    "url": "webpack-runtime-4b7ff6a9f48b8c5816ee.js"
  },
  {
    "url": "webpack-runtime-4b7ff6a9f48b8c5816ee.js.map",
    "revision": "7105244d6e6e9d339024de9d3922abfd"
  },
  {
    "url": "webpack-runtime-67688a7a4056bd48bed1.js"
  },
  {
    "url": "webpack-runtime-67688a7a4056bd48bed1.js.map",
    "revision": "1458ee141286f7fe71e78aa51c9c7978"
  },
  {
    "url": "webpack-runtime-7bc29a8831c940bb75c3.js"
  },
  {
    "url": "webpack-runtime-7bc29a8831c940bb75c3.js.map",
    "revision": "98df0cc1d618f116c84d1a2fdff94199"
  },
  {
    "url": "webpack-runtime-a1cc5cdf009f2d720eb0.js"
  },
  {
    "url": "webpack-runtime-a1cc5cdf009f2d720eb0.js.map",
    "revision": "628c80f0dec28620e4421ab9e2228e64"
  },
  {
    "url": "webpack-runtime-a5dba18b8d8732f91b47.js"
  },
  {
    "url": "webpack-runtime-a5dba18b8d8732f91b47.js.map",
    "revision": "acf8d217cd87f10afc4aa56c6b28e256"
  },
  {
    "url": "webpack-runtime-fe7a510ebdebb22a2ce4.js"
  },
  {
    "url": "webpack-runtime-fe7a510ebdebb22a2ce4.js.map",
    "revision": "5148aed223d62e9513fef42ac868074a"
  },
  {
    "url": "webpack.stats.json",
    "revision": "69ac25e07a2b3d160ac600d2f8b89cf9"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});

workbox.routing.registerRoute(/(\.js$|\.css$|static\/)/, new workbox.strategies.CacheFirst(), 'GET');
workbox.routing.registerRoute(/^https?:.*\page-data\/.*\/page-data\.json/, new workbox.strategies.StaleWhileRevalidate(), 'GET');
workbox.routing.registerRoute(/^https?:.*\.(png|jpg|jpeg|webp|svg|gif|tiff|js|woff|woff2|json|css)$/, new workbox.strategies.StaleWhileRevalidate(), 'GET');
workbox.routing.registerRoute(/^https?:\/\/fonts\.googleapis\.com\/css/, new workbox.strategies.StaleWhileRevalidate(), 'GET');

/* global importScripts, workbox, idbKeyval */

importScripts(`idb-keyval-iife.min.js`)

const { NavigationRoute } = workbox.routing

let lastNavigationRequest = null
let offlineShellEnabled = true

// prefer standard object syntax to support more browsers
const MessageAPI = {
  setPathResources: (event, { path, resources }) => {
    event.waitUntil(idbKeyval.set(`resources:${path}`, resources))
  },

  clearPathResources: event => {
    event.waitUntil(idbKeyval.clear())
  },

  enableOfflineShell: () => {
    offlineShellEnabled = true
  },

  disableOfflineShell: () => {
    offlineShellEnabled = false
  },
}

self.addEventListener(`message`, event => {
  const { gatsbyApi: api } = event.data
  if (api) MessageAPI[api](event, event.data)
})

function handleAPIRequest({ event }) {
  const { pathname } = new URL(event.request.url)

  const params = pathname.match(/:(.+)/)[1]
  const data = {}

  if (params.includes(`=`)) {
    params.split(`&`).forEach(param => {
      const [key, val] = param.split(`=`)
      data[key] = val
    })
  } else {
    data.api = params
  }

  if (MessageAPI[data.api] !== undefined) {
    MessageAPI[data.api]()
  }

  if (!data.redirect) {
    return new Response()
  }

  return new Response(null, {
    status: 302,
    headers: {
      Location: lastNavigationRequest,
    },
  })
}

const navigationRoute = new NavigationRoute(async ({ event }) => {
  // handle API requests separately to normal navigation requests, so do this
  // check first
  if (event.request.url.match(/\/.gatsby-plugin-offline:.+/)) {
    return handleAPIRequest({ event })
  }

  if (!offlineShellEnabled) {
    return await fetch(event.request)
  }

  lastNavigationRequest = event.request.url

  let { pathname } = new URL(event.request.url)
  pathname = pathname.replace(new RegExp(`^`), ``)

  // Check for resources + the app bundle
  // The latter may not exist if the SW is updating to a new version
  const resources = await idbKeyval.get(`resources:${pathname}`)
  if (!resources || !(await caches.match(`/app-278672efeec7eca81a90.js`))) {
    return await fetch(event.request)
  }

  for (const resource of resources) {
    // As soon as we detect a failed resource, fetch the entire page from
    // network - that way we won't risk being in an inconsistent state with
    // some parts of the page failing.
    if (!(await caches.match(resource))) {
      return await fetch(event.request)
    }
  }

  const offlineShell = `/offline-plugin-app-shell-fallback/index.html`
  const offlineShellWithKey = workbox.precaching.getCacheKeyForURL(offlineShell)
  return await caches.match(offlineShellWithKey)
})

workbox.routing.registerRoute(navigationRoute)

// this route is used when performing a non-navigation request (e.g. fetch)
workbox.routing.registerRoute(/\/.gatsby-plugin-offline:.+/, handleAPIRequest)
